"""Row 36 probes: kokoro-tts-pipeline tutorials/kokoro_tts_colab.ipynb (review prefix KTT, 2026-10-02 relay).

CPU-only. No model weights, no kokoro/misaki install. Run from the repository root of the reviewed commit:
    python run_probes.py [path/to/NOTEBOOK_SPEC.md]
P1 reads PyPI JSON metadata if the network is reachable; otherwise it uses the values captured during review.
P4 runs the carried pipeline module (cell 5) with injected stand-in runners; it does not synthesise speech.
"""
import json
import re
import subprocess
import sys
import urllib.request
from pathlib import Path

R = {}
NB = Path('tutorials/kokoro_tts_colab.ipynb')
nb = json.loads(NB.read_text(encoding='utf-8'))
cells = nb['cells']


def src(i):
    return ''.join(cells[i]['source'])


# P0 identity
blob = subprocess.run(['git', 'rev-parse', 'HEAD:' + NB.as_posix()], capture_output=True, text=True).stdout.strip()
head = subprocess.run(['git', 'rev-parse', 'HEAD'], capture_output=True, text=True).stdout.strip()
R['P0_identity'] = {
    'head': head, 'notebook_blob': blob, 'cells': len(cells),
    'code_cells': sum(c['cell_type'] == 'code' for c in cells),
    'metadata_dimer': nb['metadata']['dimer'],
    'persisted_outputs': sum(len(c.get('outputs', [])) for c in cells if c['cell_type'] == 'code'),
}

# P1 Python-version compatibility of the pinned packages vs the Colab kernel (3.13.15 per this repo's record)
captured = {'kokoro': '<3.13,>=3.10', 'misaki': '<3.13,>=3.8'}
live = {}
for p in captured:
    try:
        with urllib.request.urlopen(f'https://pypi.org/pypi/{p}/0.9.4/json', timeout=20) as r:
            live[p] = json.load(r)['info']['requires_python']
    except Exception as e:  # offline
        live[p] = f'unreachable: {e.__class__.__name__}'


def allows(spec, version):
    try:
        from packaging.specifiers import SpecifierSet
    except ImportError:
        return None
    return SpecifierSet(spec).contains(version)


used = {p: (captured[p] if str(live[p]).startswith('unreachable') else live[p]) for p in captured}
rv = Path('docs/release-verification.md').read_text(encoding='utf-8')
pre_install = src(3).split('subprocess.run')[0]
R['P1_python_compat'] = {
    'requires_python_live': live,
    'requires_python_captured_2026_10_03': captured,
    'allows_3.13.15': {p: allows(s, '3.13.15') for p, s in used.items()},
    'allows_3.12.12': {p: allows(s, '3.12.12') for p, s in used.items()},
    'install_cell_checks_python_version_before_pip': ('version_info' in pre_install),
    'install_cell_uses_kernel_pip': "sys.executable, '-m', 'pip', 'install'" in src(3),
    'record_names_kernel_3_13_15': '3.13.15' in rv,
    'record_says_native_attempt_aborted_in_installation': 'aborted in installation' in rv,
}

# P2 evidence vs reviewed blob
tr = Path('tutorials/README.md').read_text(encoding='utf-8')
R['P2_evidence'] = {
    'hashes_in_record': sorted(set(re.findall(r'`([0-9a-f]{40})`', rv))),
    'reviewed_blob_in_record': blob in rv,
    'record_states_no_fresh_run_of_regenerated_notebook': 'has not had a fresh GPU execution' in rv,
    'tutorials_readme_runall_verified_claim': 'verified — clean-runtime `Run all` execution recorded' in tr,
    'record_executor_isolated_python_3_12_3': 'isolated Python 3.12.3' in rv,
}

# P3 spec-version statements
R['P3_spec_versions'] = {
    'metadata': nb['metadata']['dimer']['notebook_spec'],
    'opening_says_2_0': 'Specification 2.0' in src(0),
    'release_verification_says_metadata_spec_1_1': 'spec `1.1`' in rv,
}
if len(sys.argv) > 1 and Path(sys.argv[1]).is_file():
    m = re.search(r'\*\*Version ([0-9.]+) — ([0-9-]+)\*\*', Path(sys.argv[1]).read_text(encoding='utf-8'))
    R['P3_spec_versions']['current_spec'] = list(m.groups()) if m else None

# P4 carried module with injected runners (no weights): BYOD sanity-check behaviour
ns = {}
exec(compile(src(5), 'cell5', 'exec'), ns)
import numpy as np  # noqa: E402

voices = ('af_heart', 'am_adam', 'bf_emma')


def cell13_checks(text, runner):
    pipe = ns['KokoroTTSPipeline'](runner, voices)
    try:
        result = pipe.synthesize(text, 'af_heart', speed=1.0)
    except Exception as e:
        return {'synthesize_raised': f'{type(e).__name__}: {e}'}
    lines = len([line for line in text.splitlines() if line.strip()])
    ok = len(result['segments']) == lines
    return {'segments': len(result['segments']), 'lines': lines, 'one_segment_per_line': ok, 'cell13_would_raise': not ok}


def chunking_runner(text, voice_path, speed):
    """Stand-in for upstream KPipeline.en_tokenize: a line over 510 phonemes is yielded as several chunks."""
    for line in re.split(r'\n+', text.strip()):
        if not line.strip():
            continue
        n_ps = int(len(line) * 1.15)  # stand-in: about 1.15 phoneme characters per English character
        for _ in range(max(1, -(-n_ps // 510))):
            yield line, 'x', np.zeros(2400, dtype=np.float32) + 0.1


def ood_runner(text, voice_path, speed):
    """Stand-in: a line whose words are all out-of-dictionary with no espeak fallback yields empty phonemes (skipped)."""
    for line in re.split(r'\n+', text.strip()):
        if line.strip().startswith('XQZ'):
            continue
        yield line, 'x', np.zeros(2400, dtype=np.float32) + 0.1


para = ' '.join(['The committee reviewed the proposal in detail before the vote.'] * 9)
P4 = {
    'long_single_line_chars': len(para),
    'long_single_line_within_MAX_TEXT_CHARS': len(para) <= ns['MAX_TEXT_CHARS'],
    'validate_inputs_on_long_line': ns['validate_inputs'](para, 'af_heart', voices=voices)['verdict'],
    'long_line_stand_in': cell13_checks(para, chunking_runner),
    'two_short_lines_stand_in': cell13_checks('Hello there.\nGood morning.', chunking_runner),
    'ood_line_stand_in': cell13_checks('Hello there.\nXQZ BRRT', ood_runner),
}
try:
    ns['validate_inputs']('Hi.', 'bf_emma', voices=voices)
except ValueError as e:
    P4['validate_rejects_bf_voice'] = str(e)
try:
    ns['validate_inputs']('', 'af_heart', voices=voices)
except ValueError as e:
    P4['validate_rejects_empty_text'] = str(e)
try:
    next(iter({}))
except StopIteration:
    P4['cancelled_upload_next_iter_empty'] = 'StopIteration with no message'
P4['byod_branch_requires_google_colab'] = 'from google.colab import files' in src(9)
R['P4_byod_sanity'] = P4

# P5 learner-facing text
alltext = ''.join(src(i) for i in range(len(cells)))
R['P5_text'] = {
    'prose_says_library_truncates_long_segment': 'truncates any single segment above 510 phonemes' in src(8),
    'voice_inventory_printed_for_learner': 'print(pipe.voices' in alltext or "'voices': pipe.voices" in alltext,
    'prereq_states_python_3_12': 'Python 3.12' in src(1),
    'opening_runall_claim': 'Selecting **Run all** in a fresh supported runtime' in src(0),
    'restart_instruction_in_install_cell': 'Restart the runtime, then rerun from the top' in src(3),
}

Path('results.json').write_text(json.dumps(R, indent=2, ensure_ascii=False), encoding='utf-8')
print(json.dumps(R, indent=2, ensure_ascii=False))
